from setuptools import setup, find_packages;

setup(
	name='booklover',
	version='0.1',
	packages=find_packages(),
	install_requires=[],
	description='booklovers package',
	author='tom hammons',
	author_email='thammo4@uic.edu'
);
